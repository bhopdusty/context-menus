Move "EmptyStandbyList.exe" to "C:\Windows"

Continue

Open "Services.msc"

NVIDIA Display Container LS

Properties

Startup Type: Manual

Stop

Start if You need to Access NVIDIA Control Panel