Run "ImportPowerPlans.bat"

Edit "PowerPlanToggle.bat"

Open "CMD" Type: powercfg /L

Find "Idle Disabled"

Replace "56258c4c-6c0c-4fba-af1c-21c77bfeba1b" in "PowerPlanToggle.bat" to Your Idle Disabled Power Plan GUID

Find "Idle Enabled" in CMD

Replace "aed0a3b1-f55f-4b4e-a457-ec311e15a077" in "PowerPlanToggle.bat" to Your Idle Enabled Power Plan GUID