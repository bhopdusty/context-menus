Move all Folders to "%USERPROFILE%\Documents" Before Doing Next Step

Open Toggles then Each Folder Inside and Read everything

If You're Using Portable-OBS Move Your Portable Versions Inside %USERPROFILE%\Documents\OBS\Recording or \ReplayBuffer or \Streaming