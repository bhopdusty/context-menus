MAKE SURE YOUR MONITOR HAS DISPLAY SCALING BEFORE DOING THIS

Open "CRU" Choose Your Main Display

Delete all "Established Resolutions"

Delete all "Detailed Resolutions"

Delete all "Standard Resolutions"

Edit "Extension Block"

Delete "TV Resolutions" from "Data Blocks"

Edit "Detailed Resolutions"

Copy Your Main Resolution (Proper FPS)

Delete "Detailed Resolutions"

Go Back to Main Page

Add "Detailed Resolutions"

Paste, Ok

For "CRU" (Not Toggle)

Export, Save as Type: .exe, Rename to "1920x1080", Save in Same Folder "%USERPROFILE%\Documents\Toggles\CRU\1920x1080.exe"

Now Edit "Detailed Resolutions" Change "1920" to "1728", Ok, Export, Save as Type: .exe, Rename to "1728x1080", Save in Same Folder "%USERPROFILE%\Documents\Toggles\CRU\1728x1080.exe"

Now Edit "Detailed Resolutions" Change "1728" to "1440", Ok, Export, Save as Type: .exe, Rename to "1440x1080", Save in Same Folder "%USERPROFILE%\Documents\Toggles\CRU\1440x1080.exe"

For "CRU-Toggle"

Export, Save as Type: .exe, Rename to "1920x1080", Save in Same Folder "%USERPROFILE%\Documents\Toggles\CRU\1920x1080.exe"

Now Edit "Detailed Resolutions" Change "1920" to "1728" or "1440" (16:10 or 4:3), Ok, Export, Save as Type: .exe, Rename to "1440x1080" (No Matter What You Set The Resolution To), Save in Same Folder "%USERPROFILE%\Documents\Toggles\CRU\1440x1080.exe"