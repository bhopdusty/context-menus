Open "NSudo"

Check "Enable  All Privileges"

Browse

Import "Context Menus\Files Needed After\Other\Remove Display Settings and Personalize from Context Menu.reg"

Run, Yes, Ok

(You can Search for Personalize or Display Settings in Windows)